import UserProfile from '../models/UserProfile.js';

// ✅ Get User Profile
export const getProfile = async (req, res) => {
  try {
    const user = await UserProfile.findById(req.user.id);
    if (!user) {
      console.log('❌ User not found:', req.user.id);
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    console.log('📌 Retrieved User Profile:', user);

    res.status(200).json({
      success: true,
      data: {
        phoneNumber: user.phoneNumber,
        name: user.name,
        username: user.username,
        dateOfBirth: user.dateOfBirth,
        gender: user.gender,
        height: user.height,
        interests: user.interests,
        values: user.values,
        prompts: user.prompts,
        photos: user.photos,
        location: user.location, // ✅ Logs location data
      },
    });
  } catch (error) {
    console.error('❌ Error fetching profile:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

// ✅ Update User Location
export const updateLocation = async (req, res) => {
  try {
    const { latitude, longitude } = req.body;

    if (!latitude || !longitude) {
      console.error('❌ Invalid location data received:', req.body);
      return res.status(400).json({ success: false, message: 'Invalid location data' });
    }

    console.log('📌 Updating location for user:', req.user.id, 'to:', { latitude, longitude });

    const user = await UserProfile.findById(req.user.id);
    if (!user) {
      console.log('❌ User not found for location update:', req.user.id);
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    user.location = { latitude, longitude };
    await user.save();

    console.log('✅ Location updated successfully:', user.location);

    res.status(200).json({ success: true, message: 'Location updated successfully', location: user.location });
  } catch (error) {
    console.error('❌ Error updating location:', error);
    res.status(500).json({ success: false, message: 'Failed to update location' });
  }
};
