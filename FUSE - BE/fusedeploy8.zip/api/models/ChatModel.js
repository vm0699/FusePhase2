import mongoose from "mongoose";

const ChatSchema = new mongoose.Schema({
  senderId: { type: mongoose.Schema.Types.ObjectId, ref: "UserProfile", required: true },
  receiverId: { type: mongoose.Schema.Types.ObjectId, ref: "UserProfile", required: true },
  twilioChatChannelSid: { type: String, unique: true }, // ✅ Renamed to match usage
  messages: [
    {
      sender: { type: mongoose.Schema.Types.ObjectId, ref: "UserProfile" },
      message: { type: String, required: true },
      timestamp: { type: Date, default: Date.now }
    }
  ],
  status: { type: String, enum: ["pending", "accepted"], default: "pending" } // ✅ Ensure chat status exists
});

export default mongoose.model("Chat", ChatSchema);
