import Chat from "../models/ChatModel.js";
import UserProfile from "../models/UserProfile.js";
import client from "../config/twilio.js";
import dotenv from "dotenv";
import twilio from "twilio";

dotenv.config();


/** ✅ Fetch or Create Chat Channel */
export const fetchOrCreateChatChannel = async (senderId, receiverId) => {
  try {
    console.log(`🔹 Fetching or Creating Chat Channel for Sender: ${senderId} and Receiver: ${receiverId}`);

    let chat = await Chat.findOne({
      $or: [
        { senderId, receiverId },
        { senderId: receiverId, receiverId: senderId },
      ],
    });

    let channel;
    if (!chat) {
      console.log("🔹 No existing chat found, creating a new Twilio Chat channel.");

      // ✅ Create a new chat channel
      channel = await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
        .channels
        .create({ 
          friendlyName: `${senderId}-${receiverId}`, 
          uniqueName: `chat-${senderId}-${receiverId}`
        });

      // ✅ Re-fetch channel so `.members` is available
      channel = await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
        .channels(channel.sid)
        .fetch();

      console.log(`✅ New Twilio Chat Channel Created: ${channel.sid}`);

      chat = new Chat({
        senderId,
        receiverId,
        twilioChatChannelSid: channel.sid,
        messages: [],
        status: "pending", // ✅ Set to pending until manually accepted
      });

      await chat.save();
    } else {
      if (!chat.twilioChatChannelSid) {
        console.warn("⚠️ Chat exists but no Twilio SID found. Creating new channel...");

        // ✅ Create and fetch Twilio channel
        channel = await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
          .channels
          .create({ 
            friendlyName: `${senderId}-${receiverId}`, 
            uniqueName: `chat-${senderId}-${receiverId}`
          });

        channel = await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
          .channels(channel.sid)
          .fetch();

        chat.twilioChatChannelSid = channel.sid;
        await chat.save();

        console.log(`✅ Twilio Channel Created & Chat Updated: ${channel.sid}`);
      } else {
        console.log(`ℹ️ Using Existing Twilio Chat Channel: ${chat.twilioChatChannelSid}`);
        channel = await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
          .channels(chat.twilioChatChannelSid)
          .fetch();
      }
    }

    // ✅ Ensure both sender and receiver are members of the chat
    const members = await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
      .channels(channel.sid)
      .members
      .list();

    const memberSIDs = members.map(m => m.identity);

    if (!memberSIDs.includes(senderId)) {
      console.log(`🔹 Adding sender (${senderId}) to channel...`);
      await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
        .channels(channel.sid)
        .members
        .create({ identity: senderId });
    }

    if (!memberSIDs.includes(receiverId)) {
      console.log(`🔹 Adding receiver (${receiverId}) to channel...`);
      await client.chat.v2.services(process.env.TWILIO_CHAT_SERVICE_SID)
        .channels(channel.sid)
        .members
        .create({ identity: receiverId });
    }

    return { success: true, chat, channel };
  } catch (error) {
    console.error("❌ Error in fetchOrCreateChatChannel:", error.message);
    return { success: false, message: "Failed to fetch or create chat channel", error: error.message };
  }
};




/** ✅ Send Compliment & Initiate Chat */
export const sendCompliment = async (req, res) => {
  try {
    const { swipedUserId, compliment } = req.body;
    const senderId = req.user.id;
    const senderUsername = req.user.username;

    if (!swipedUserId) {
      return res.status(400).json({ success: false, message: "Missing recipient ID" });
    }

    console.log(`🔹 Sending Compliment from ${senderId} to ${swipedUserId}: "${compliment}"`);

    const { chat, channel } = await fetchOrCreateChatChannel(senderId, swipedUserId);

    if (!channel || !channel.sid) {
      return res.status(500).json({ success: false, message: "Failed to create or fetch Twilio chat channel" });
    }

    if (compliment) {
      console.log("📩 Sending compliment message to Twilio chat...");

      await client.chat.services(process.env.TWILIO_CHAT_SERVICE_SID)
        .channels(channel.sid)
        .messages
        .create({ from: senderUsername, body: compliment });

      // ✅ Do not set chat.status = "accepted" here.
      // Let it be manually accepted by the recipient via handleChatRequest.
    }

    await chat.save();
    console.log(`✅ Chat saved with status: ${chat.status}`);

    res.status(200).json({
      success: true,
      message: "Compliment sent successfully!",
      chatChannelSid: chat.twilioChatChannelSid,
    });
  } catch (error) {
    console.error("❌ Error sending compliment:", error.message);
    res.status(500).json({ success: false, message: "Failed to send compliment", error: error.message });
  }
};



/** ✅ Fetch User Chats */
/** ✅ Fetch User Chats */
/** ✅ Fetch User Chats */
export const getUserChats = async (req, res) => {
  try {
    const userId = req.user.id;
    console.log(`🔍 Fetching chats for User ID: ${userId}`);

    let chats = await Chat.find({
      $or: [{ senderId: userId }, { receiverId: userId }],
      status: { $in: ["accepted", "pending"] },
    }).populate("receiverId senderId");

    if (!chats || chats.length === 0) {
      console.log("ℹ️ No chats found for user.");
      return res.status(200).json({ success: true, chats: [] });
    }

    const formattedChats = chats.map(chat => {
      let isCurrentUserSender = chat.senderId._id.toString() === userId;
      let otherUser = isCurrentUserSender ? chat.receiverId : chat.senderId;

      if (!otherUser || !otherUser.name) {
        console.warn(`⚠️ Missing user data for chat: ${chat._id}`);
        return null;
      }

      return {
        _id: chat._id,
        twilioChatChannelSid: chat.twilioChatChannelSid,
        user: {
          id: otherUser._id,
          name: otherUser.name || "Unknown User",
          username: otherUser.username || "",
        },
        lastMessage: chat.messages.length > 0 ? chat.messages[chat.messages.length - 1] : null,
        status: chat.status,
        actualReceiverId: chat.receiverId._id.toString(), // ✅ include for ChatScreen logic
      };
    }).filter(chat => chat !== null);

    console.log(`✅ Successfully fetched ${formattedChats.length} chats`);
    res.status(200).json({ success: true, chats: formattedChats });
  } catch (error) {
    console.error("❌ Error fetching chats:", error.message);
    res.status(500).json({ success: false, message: "Failed to retrieve chats", error: error.message });
  }
};







/** ✅ Handle Chat Request Accept/Decline */
export const handleChatRequest = async (req, res) => {
  try {
    const { chatId, action } = req.body;
    const userId = req.user.id;

    const chat = await Chat.findById(chatId);

    if (!chat) {
      return res.status(404).json({ success: false, message: "Chat not found" });
    }

    if (chat.receiverId.toString() !== userId) {
      return res.status(403).json({ success: false, message: "Unauthorized to modify this chat request" });
    }

    if (action === "accept") {
      chat.status = "accepted";
      await chat.save();
      console.log(`✅ Chat ${chatId} accepted by receiver ${userId}`);
      return res.status(200).json({ success: true, message: "Chat request accepted!" });
    }

    if (action === "decline") {
      await Chat.findByIdAndDelete(chatId);
      console.log(`❌ Chat ${chatId} declined and deleted by receiver ${userId}`);
      return res.status(200).json({ success: true, message: "Chat request declined!" });
    }

    return res.status(400).json({ success: false, message: "Invalid action" });

  } catch (error) {
    console.error("❌ Error handling chat request:", error);
    return res.status(500).json({ success: false, message: "Failed to process chat request", error: error.message });
  }
};




export const getTwilioToken = async (req, res) => {
  try {
    const { id: userId, username } = req.user;

    if (!userId || !username) {
      return res.status(401).json({ success: false, message: "Unauthorized - Missing user info" });
    }

    console.log("🔹 Received request for Twilio token...");
    console.log(`✅ Generating Twilio token for username: ${username}`);

    const AccessToken = twilio.jwt.AccessToken;
    const ChatGrant = AccessToken.ChatGrant;

    const token = new AccessToken(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_API_KEY_SID,
      process.env.TWILIO_API_KEY_SECRET,
      { identity: username } // ✅ Real Twilio identity
    );

    token.addGrant(
      new ChatGrant({
        serviceSid: process.env.TWILIO_CHAT_SERVICE_SID,
      })
    );

    console.log(`✅ Twilio token generated successfully for ${username}`);
    res.status(200).json({ token: token.toJwt() });

  } catch (error) {
    console.error("❌ Error generating Twilio token:", error);
    res.status(500).json({ success: false, message: "Failed to generate token", error: error.message });
  }
};
