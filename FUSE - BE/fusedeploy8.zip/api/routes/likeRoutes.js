import { Router } from "express";
import Like from "../models/Like.js";
import UserProfile from "../models/UserProfile.js";
import authMiddleware from "../middleware/authMiddleware.js"; // ✅ Correct way

const router = Router(); // ✅ Using Router()

// 🔵 Route: Like a user
router.post("/like", authMiddleware, async (req, res) => {
  try {
    const { likedUserId } = req.body;
    const likerId = req.user.id;

    if (!likedUserId) {
      return res.status(400).json({ success: false, message: "Liked user ID missing" });
    }

    // Check if already liked
    const existingLike = await Like.findOne({ likerId, likedUserId });
    if (existingLike) {
      return res.status(400).json({ success: false, message: "Already liked" });
    }

    const newLike = await Like.create({ likerId, likedUserId });

    return res.status(201).json({ success: true, message: "User liked successfully", like: newLike });
  } catch (error) {
    console.error("Error liking user:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// 🔵 Route: Get users who liked you
router.get("/likedyou", authMiddleware, async (req, res) => {
  try {
    const userId = req.user.id;

    const likes = await Like.find({ likedUserId: userId }).populate("likerId");

    const usersWhoLikedYou = likes.map((like) => like.likerId);

    res.status(200).json({ success: true, users: usersWhoLikedYou });
  } catch (error) {
    console.error("Error fetching likes:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

export default router;
